const quizData = {
    easy: [
        {
            question: "Który zespół wydał album 'The Dark Side of the Moon'?",
            answers: [
                "Led Zeppelin",
                "Pink Floyd",
                "The Rolling Stones",
                "The Beatles"
            ],
            correct: 1
        },
        {
            question: "Który zespół jest znany z utworu 'Stairway to Heaven'?",
            answers: [
                "The Who",
                "Deep Purple",
                "Led Zeppelin",
                "Queen"
            ],
            correct: 2
        },
        {
            question: "Który zespół ma wokalistę o pseudonimie 'Ozzy'?",
            answers: [
                "Metallica",
                "Black Sabbath",
                "Guns N' Roses",
                "AC/DC"
            ],
            correct: 1
        },
        {
            question: "Który zespół wydał album 'Back in Black'?",
            answers: [
                "Aerosmith",
                "AC/DC",
                "Van Halen",
                "Kiss"
            ],
            correct: 1
        },
        {
            question: "Który zespół ma gitarzystę o imieniu Slash?",
            answers: [
                "Nirvana",
                "Guns N' Roses",
                "Red Hot Chili Peppers",
                "The Doors"
            ],
            correct: 1
        },
        {
            question: "Który zespół wydał utwór 'Bohemian Rhapsody'?",
            answers: [
                "The Beatles",
                "Queen",
                "The Rolling Stones",
                "Pink Floyd"
            ],
            correct: 1
        },
        {
            question: "Który zespół ma perkusistę o pseudonimie 'Animal'?",
            answers: [
                "The Muppets",
                "The Who",
                "Led Zeppelin",
                "Kiss"
            ],
            correct: 0
        },
        {
            question: "Który zespół wydał album 'Nevermind'?",
            answers: [
                "Pearl Jam",
                "Soundgarden",
                "Nirvana",
                "Alice in Chains"
            ],
            correct: 2
        },
        {
            question: "Który zespół ma wokalistę o imieniu Bono?",
            answers: [
                "U2",
                "Coldplay",
                "Radiohead",
                "The Cure"
            ],
            correct: 0
        },
        {
            question: "Który zespół wydał utwór 'Smells Like Teen Spirit'?",
            answers: [
                "Green Day",
                "Blink-182",
                "Nirvana",
                "The Offspring"
            ],
            correct: 2
        }
    ],
    medium: [
        {
            question: "Który zespół nagrał utwór 'Hotel California'?",
            answers: [
                "The Doors",
                "The Eagles",
                "Fleetwood Mac",
                "Lynyrd Skynyrd"
            ],
            correct: 1
        },
        {
            question: "Który zespół ma gitarzystę o imieniu The Edge?",
            answers: [
                "U2",
                "Radiohead",
                "The Cure",
                "R.E.M."
            ],
            correct: 0
        },
        {
            question: "Który zespół wydał album 'Appetite for Destruction'?",
            answers: [
                "Metallica",
                "Guns N' Roses",
                "Motley Crue",
                "Def Leppard"
            ],
            correct: 1
        },
        {
            question: "Który zespół ma wokalistkę o imieniu Stevie Nicks?",
            answers: [
                "Heart",
                "Fleetwood Mac",
                "Blondie",
                "The Pretenders"
            ],
            correct: 1
        },
        {
            question: "Który zespół wydał utwór 'Sweet Child O' Mine'?",
            answers: [
                "Aerosmith",
                "Bon Jovi",
                "Guns N' Roses",
                "Van Halen"
            ],
            correct: 2
        },
        {
            question: "Który zespół ma basistę o pseudonimie Flea?",
            answers: [
                "Red Hot Chili Peppers",
                "Foo Fighters",
                "Nirvana",
                "Pearl Jam"
            ],
            correct: 0
        },
        {
            question: "Który zespół wydał album 'The Joshua Tree'?",
            answers: [
                "U2",
                "The Police",
                "Talking Heads",
                "R.E.M."
            ],
            correct: 0
        },
        {
            question: "Który zespół ma perkusistę o imieniu Lars Ulrich?",
            answers: [
                "Megadeth",
                "Slayer",
                "Metallica",
                "Anthrax"
            ],
            correct: 2
        },
        {
            question: "Który zespół wydał utwór 'Livin' on a Prayer'?",
            answers: [
                "Journey",
                "Bon Jovi",
                "Foreigner",
                "REO Speedwagon"
            ],
            correct: 1
        },
        {
            question: "Który zespół ma wokalistę o imieniu Robert Plant?",
            answers: [
                "Deep Purple",
                "Led Zeppelin",
                "The Who",
                "Black Sabbath"
            ],
            correct: 1
        }
    ],
    hard: [
        {
            question: "Który zespół wydał album 'In the Court of the Crimson King'?",
            answers: [
                "Yes",
                "Emerson, Lake & Palmer",
                "Jethro Tull",
                "King Crimson"
            ],
            correct: 3
        },
        {
            question: "Który zespół ma gitarzystę o pseudonimie 'Buckethead'?",
            answers: [
                "Guns N' Roses",
                "Primus",
                "Tool",
                "Rage Against the Machine"
            ],
            correct: 0
        },
        {
            question: "Który zespół wydał album 'Lateralus'?",
            answers: [
                "A Perfect Circle",
                "Tool",
                "Puscifer",
                "Nine Inch Nails"
            ],
            correct: 1
        },
        {
            question: "Który zespół ma perkusistę o imieniu Danny Carey?",
            answers: [
                "Soundgarden",
                "Tool",
                "Alice in Chains",
                "Stone Temple Pilots"
            ],
            correct: 1
        },
        {
            question: "Który zespół wydał utwór 'Schism'?",
            answers: [
                "Deftones",
                "Korn",
                "Tool",
                "System of a Down"
            ],
            correct: 2
        },
        {
            question: "Który zespół ma wokalistę o imieniu Maynard James Keenan?",
            answers: [
                "A Perfect Circle",
                "Puscifer",
                "Tool",
                "Wszystkie powyższe"
            ],
            correct: 3
        },
        {
            question: "Który zespół wydał album 'Frances the Mute'?",
            answers: [
                "The Mars Volta",
                "At the Drive-In",
                "Coheed and Cambria",
                "Circa Survive"
            ],
            correct: 0
        },
        {
            question: "Który zespół ma gitarzystę o imieniu Tom Morello?",
            answers: [
                "Rage Against the Machine",
                "Audioslave",
                "Prophets of Rage",
                "Wszystkie powyższe"
            ],
            correct: 3
        },
        {
            question: "Który zespół wydał album 'Kid A'?",
            answers: [
                "Radiohead",
                "Muse",
                "Coldplay",
                "The Smashing Pumpkins"
            ],
            correct: 0
        },
        {
            question: "Który zespół ma basistę o imieniu Les Claypool?",
            answers: [
                "Primus",
                "Fishbone",
                "Infectious Grooves",
                "Wszystkie powyższe"
            ],
            correct: 3
        }
    ]
};

let currentQuestion = 0;
let score = 0;
let userAnswers = [];
let currentDifficulty = 'easy';

const startSection = document.getElementById('start-section');
const quizSection = document.getElementById('quiz-section');
const resultsSection = document.getElementById('results-section');
const easyBtn = document.getElementById('easy-btn');
const mediumBtn = document.getElementById('medium-btn');
const hardBtn = document.getElementById('hard-btn');
const nextBtn = document.getElementById('next-btn');
const restartBtn = document.getElementById('restart-btn');
const questionText = document.getElementById('question-text');
const answersContainer = document.getElementById('answers-container');
const questionCounter = document.getElementById('question-counter');
const scoreElement = document.getElementById('score');
const progress = document.getElementById('progress');
const currentDifficultyElement = document.getElementById('current-difficulty');
const resultDifficultyElement = document.getElementById('result-difficulty');
const finalScore = document.getElementById('final-score');
const scoreValue = document.getElementById('score-value');
const resultMessage = document.getElementById('result-message');

function startQuiz(difficulty) {
    currentDifficulty = difficulty;
    currentQuestion = 0;
    score = 0;
    userAnswers = [];
    
    startSection.classList.remove('active');
    quizSection.classList.add('active');
    
    setDifficultyColors(difficulty);
    
    showQuestion();
    updateProgress();
}

function setDifficultyColors(difficulty) {
    progress.className = 'progress';
    progress.classList.add(difficulty);
    
    currentDifficultyElement.textContent = getDifficultyName(difficulty);
    currentDifficultyElement.className = 'difficulty-badge';
    currentDifficultyElement.classList.add(difficulty);

    finalScore.className = 'final-score';
    finalScore.classList.add(difficulty);

    resultDifficultyElement.textContent = getDifficultyName(difficulty);
    resultDifficultyElement.className = 'difficulty-badge';
    resultDifficultyElement.classList.add(difficulty);
}

function getDifficultyName(difficulty) {
    switch(difficulty) {
        case 'easy': return 'Łatwy';
        case 'medium': return 'Średni';
        case 'hard': return 'Trudny';
        default: return 'Łatwy';
    }
}

function showQuestion() {
    const questions = quizData[currentDifficulty];
    const question = questions[currentQuestion];
    
    questionText.textContent = question.question;
    answersContainer.innerHTML = '';
    
    question.answers.forEach((answer, index) => {
        const button = document.createElement('button');
        button.classList.add('answer-btn');
        button.textContent = answer;
        button.addEventListener('click', () => selectAnswer(index));
        answersContainer.appendChild(button);
    });
    
    questionCounter.textContent = `Pytanie ${currentQuestion + 1}/${questions.length}`;
    scoreElement.textContent = `Wynik: ${score}/${currentQuestion}`;
    nextBtn.disabled = true;
}

function selectAnswer(index) {
    userAnswers[currentQuestion] = index;
    
    const buttons = document.querySelectorAll('.answer-btn');
    buttons.forEach(button => {
        button.disabled = true;
    });
    
    const questions = quizData[currentDifficulty];
    const question = questions[currentQuestion];
    
    if (index === question.correct) {
        buttons[index].classList.add('correct');
        score++;
    } else {
        buttons[index].classList.add('incorrect');
        buttons[question.correct].classList.add('correct');
    }
    
    scoreElement.textContent = `Wynik: ${score}/${currentQuestion + 1}`;
    nextBtn.disabled = false;
}

function nextQuestion() {
    const questions = quizData[currentDifficulty];
    currentQuestion++;
    
    if (currentQuestion < questions.length) {
        showQuestion();
        updateProgress();
    } else {
        showResults();
    }
}

function updateProgress() {
    const questions = quizData[currentDifficulty];
    const progressPercent = ((currentQuestion + 1) / questions.length) * 100;
    progress.style.width = `${progressPercent}%`;
}

function showResults() {
    const questions = quizData[currentDifficulty];
    
    quizSection.classList.remove('active');
    resultsSection.classList.add('active');
    
    scoreValue.textContent = score;
  
    if (score === questions.length) {
        resultMessage.textContent = "Fantastycznie! Jesteś prawdziwym ekspertem rocka!";
    } else if (score >= questions.length * 0.7) {
        resultMessage.textContent = "Dobrze Ci poszło! Znasz się na rocku!";
    } else if (score >= questions.length * 0.5) {
        resultMessage.textContent = "Nieźle, ale możesz jeszcze poprawić swoją wiedzę o rocku!";
    } else {
        resultMessage.textContent = "Warto posłuchać więcej klasyków rocka!";
    }
}

function restartQuiz() {
    resultsSection.classList.remove('active');
    startSection.classList.add('active');
}

easyBtn.addEventListener('click', () => startQuiz('easy'));
mediumBtn.addEventListener('click', () => startQuiz('medium'));
hardBtn.addEventListener('click', () => startQuiz('hard'));
nextBtn.addEventListener('click', nextQuestion);
restartBtn.addEventListener('click', restartQuiz);